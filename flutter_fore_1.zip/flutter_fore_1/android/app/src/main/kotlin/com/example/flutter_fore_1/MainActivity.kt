package com.example.flutter_fore_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
